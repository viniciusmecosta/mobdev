class AppRoutes {
  static const String PLACE_FORM = '/place-form';
  static const String PLACE_DETAIL = '/place-detail';
}
